package com.example.providerservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProviderServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
