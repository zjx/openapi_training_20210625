package com.example.providerservice.uitls;

import org.springframework.stereotype.Component;
import org.springframework.web.filter.FormContentFilter;

@Component
public class PutFilter extends FormContentFilter {
}
